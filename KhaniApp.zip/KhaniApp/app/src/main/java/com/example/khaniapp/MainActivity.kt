package com.example.khaniapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var storyAdapter: StoryAdapter
    private lateinit var storyDatabase: StoryDatabase
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawerLayout = findViewById(R.id.drawerlayout)
        navigationView = findViewById(R.id.navigationView)

        val toggle = ActionBarDrawerToggle(this , drawerLayout , toolbar , R.string.open , R.string.close)
        toggle.isDrawerIndicatorEnabled = true

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.home -> {
                    // Handle Home action

                }
                R.id.random -> {
                    // Handle Random Story action
                    navigateToRandomStory()
                }
                R.id.savestories -> {
                    val savedStoriesFragment = SavedStoriesFragment()
                    findViewById<View>(R.id.contant_main).visibility = View.GONE
                    findViewById<FrameLayout>(R.id.fragmentContainer).visibility = View.VISIBLE

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, savedStoriesFragment)
                        .addToBackStack(null)
                        .commit()
                }

                R.id.cat -> {
                    // Handle Categories action
                    val categoriesFragment = CategoriesFragment()
                    findViewById<View>(R.id.contant_main).visibility = View.GONE
                    findViewById<FrameLayout>(R.id.fragmentContainer).visibility = View.VISIBLE

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, categoriesFragment)
                        .addToBackStack(null)
                        .commit()




                }
                R.id.contact -> {
                    // Handle Contact Us action
                    val contactUsFragment = ContactUsFragment()
                    findViewById<View>(R.id.contant_main).visibility = View.GONE
                    findViewById<FrameLayout>(R.id.fragmentContainer).visibility = View.VISIBLE

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, contactUsFragment)
                        .addToBackStack(null)
                        .commit()

                }
                R.id.rate -> {
                    // Handle Rate Us action
                    showRateUsDialog()
                }

            }
            drawerLayout.closeDrawers()
            true


        }


        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager=LinearLayoutManager(this)

        storyAdapter = StoryAdapter(emptyList() , onClick = { story ->
            val intent = Intent(this, StoryActivity::class.java)
            intent.putExtra("STORY_ID", story.id)
            startActivity(intent)
        } ,
            onStoryLongClick = { story ->
                showStoryOptionsDialog(story)
            } )
        recyclerView.adapter = storyAdapter

        storyDatabase = StoryDatabase.getInstance(this)
        storyDatabase.storyDao().getAllStories().observe(this){stories ->
            storyAdapter.updateStories(stories)

        }

        findViewById<FloatingActionButton>(R.id.fab_add_story).setOnClickListener {
            startActivity(Intent(this, StoryUploadActivity::class.java))
        }
    }

    private fun navigateToRandomStory() {
        // Assuming `storyAdapter` holds the list of stories
        val stories = (storyAdapter as StoryAdapter).getStories()

        if (stories.isNotEmpty()) {
            val randomStory = stories.random() // Select a random story

            // Redirect to StoryActivity with the selected story
            val intent = Intent(this, StoryActivity::class.java).apply {
                putExtra("STORY_ID", randomStory.id) // Pass the story ID
            }
            startActivity(intent)
        } else {
            Toast.makeText(this, "No stories available", Toast.LENGTH_SHORT).show()
        }
    }


    private fun showStoryOptionsDialog(story: Story) {
        val options = arrayOf("Edit", "Delete")
        AlertDialog.Builder(this)
            .setTitle("Select Action")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> editStory(story) // Edit option
                    1 -> deleteStory(story) // Delete option
                }
            }
            .show()
    }

    private fun editStory(story: Story) {
        val intent = Intent(this, StoryUploadActivity::class.java)
        intent.putExtra("STORY_ID", story.id)
        intent.putExtra("STORY_TITLE", story.title)
        intent.putExtra("STORY_DESCRIPTION", story.description)
        intent.putExtra("STORY_AUTHOR", story.author)
        intent.putExtra("STORY_IMAGE_PATH", story.imagePath)
        startActivityForResult(intent, REQUEST_CODE_ADD_STORY)
    }

    private fun deleteStory(story: Story) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                storyDatabase.storyDao().deleteStory(story)
            }
            // Refresh the RecyclerView
            val updatedStories = storyDatabase.storyDao().getAllStories().value ?: emptyList()
            storyAdapter.updateStories(updatedStories)
            Toast.makeText(this@MainActivity, "Story deleted", Toast.LENGTH_SHORT).show()
        }
    }



    companion object {
        const val REQUEST_CODE_ADD_STORY = 101
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_ADD_STORY && resultCode == RESULT_OK) {
            // Refresh the stories when returning from StoryUploadActivity
            storyDatabase.storyDao().getAllStories().value?.let { stories ->
                storyAdapter.updateStories(stories)
            }
        }
    }

    override fun onBackPressed() {
        val fragment = supportFragmentManager.findFragmentById(R.id.fragmentContainer)

        if (fragment != null) {
            // If a fragment is currently displayed, remove it and show the main content
            supportFragmentManager.popBackStack()
            findViewById<View>(R.id.fragmentContainer).visibility = View.GONE
            findViewById<View>(R.id.contant_main).visibility = View.VISIBLE
        } else {
            // If no fragment is displayed, follow the default back behavior
            super.onBackPressed()
        }
    }

    private fun showRateUsDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Rate Us")
            .setMessage("Do you enjoy using our app? Please take a moment to rate us!")
            .setPositiveButton("Rate Now") { _, _ -> openRateUsPage() }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
        builder.create().show()
    }
    private fun openRateUsPage() {
        try {
            // Open Play Store directly
            val playStoreIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=${applicationContext.packageName}")
            )
            startActivity(playStoreIntent)
        } catch (e: Exception) {
            // Fallback if Play Store app is not available
            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=${applicationContext.packageName}")
            )
            startActivity(browserIntent)
        }
    }



}

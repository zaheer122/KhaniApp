package com.example.khaniapp

import androidx.recyclerview.widget.DiffUtil

class SavedStoryDiffCallback : DiffUtil.ItemCallback<SavedStory>() {
    override fun areItemsTheSame(oldItem: SavedStory, newItem: SavedStory): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: SavedStory, newItem: SavedStory): Boolean {
        return oldItem == newItem
    }
}

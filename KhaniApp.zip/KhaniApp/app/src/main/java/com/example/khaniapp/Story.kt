package com.example.khaniapp
import androidx.room.Entity
import androidx.room.PrimaryKey
import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "stories")
data class Story(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val author: String,
    val imageUri: Uri? ,
    val imagePath: String
) : Parcelable

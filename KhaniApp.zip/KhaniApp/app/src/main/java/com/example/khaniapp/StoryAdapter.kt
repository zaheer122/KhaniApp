package com.example.khaniapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class StoryAdapter(
    private var stories: List<Story>,
    private val onClick: (Story) -> Unit ,
    private val onStoryLongClick: (Story) -> Unit
) : RecyclerView.Adapter<StoryAdapter.StoryViewHolder>() {

    inner class StoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title)
        val description: TextView = view.findViewById(R.id.description)
        val image: ImageView = view.findViewById(R.id.image)
    }

    fun updateStories(newStories: List<Story>) {
        this.stories = newStories
        notifyDataSetChanged()
    }

    fun getStories(): List<Story> {
        return stories
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_story, parent, false)
        return StoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        val story = stories[position]
        holder.title.text = story.title
        holder.description.text = story.description
        holder.image.setImageURI(story.imageUri)

        holder.itemView.setOnClickListener { onClick(story) }
        holder.itemView.setOnLongClickListener {
            onStoryLongClick(story) // Handle long-click
            true
        }
    }

    override fun getItemCount() = stories.size
}

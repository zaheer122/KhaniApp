package com.example.khaniapp

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import android.Manifest
import android.graphics.Bitmap

class StoryUploadActivity : AppCompatActivity() {

    private val STORAGE_PERMISSION_CODE = 100

    private lateinit var editTextTitle: EditText
    private lateinit var editTextDescription: EditText
    private lateinit var buttonSelectImage: Button
    private lateinit var buttonSaveStory: Button
    private lateinit var imageViewPreview: ImageView
    private var imageUri: Uri? = null
    private lateinit var editTextAuthor: EditText

    private var storyId: Int = -1 // Story ID for editing (default -1 for new stories)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_story_upload)

        // Initialize views
        editTextTitle = findViewById(R.id.editTextTitle)
        editTextDescription = findViewById(R.id.editTextDescription)
        editTextAuthor = findViewById(R.id.editTextAuthor)
        buttonSelectImage = findViewById(R.id.buttonSelectImage)
        buttonSaveStory = findViewById(R.id.buttonSaveStory)
        imageViewPreview = findViewById(R.id.imageViewPreview)

        // Set listeners
        buttonSelectImage.setOnClickListener { checkStoragePermissionAndSelectImage() }
        buttonSaveStory.setOnClickListener { saveStory() }

        // Check if editing an existing story
        if (intent != null && intent.hasExtra("STORY_ID")) {
            storyId = intent.getIntExtra("STORY_ID", -1)
            val title = intent.getStringExtra("STORY_TITLE") ?: ""
            val description = intent.getStringExtra("STORY_DESCRIPTION") ?: ""
            val author = intent.getStringExtra("STORY_AUTHOR") ?: ""
            val imagePath = intent.getStringExtra("STORY_IMAGE_PATH")

            // Pre-fill fields
            editTextTitle.setText(title)
            editTextDescription.setText(description)
            editTextAuthor.setText(author)

            // Load image if available
            imagePath?.let {
                val bitmap = BitmapFactory.decodeFile(it)
                imageViewPreview.setImageBitmap(bitmap)
                imageViewPreview.visibility = ImageView.VISIBLE
            }

            // Update button text
            buttonSaveStory.text = "Update Story"
        }
    }

    private fun checkStoragePermissionAndSelectImage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13 and above: Request READ_MEDIA_IMAGES
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_MEDIA_IMAGES), STORAGE_PERMISSION_CODE)
            } else {
                selectImage()
            }
        } else {
            // Android 12 and below: Request READ_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), STORAGE_PERMISSION_CODE)
            } else {
                selectImage()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectImage() // Permission granted
            } else {
                Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun selectImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        imagePickerLauncher.launch(intent)
    }

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            imageUri = data?.data
            imageUri?.let {
                imageViewPreview.setImageURI(it)
                imageViewPreview.visibility = ImageView.VISIBLE
            }
        }
    }

    private fun saveStory() {
        val title = editTextTitle.text.toString().trim()
        val author = editTextAuthor.text.toString().trim()
        val description = editTextDescription.text.toString().trim()

        // Validate inputs
        if (title.isEmpty() || description.isEmpty() || author.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (imageUri == null && storyId == -1) { // New story requires an image
            Toast.makeText(this, "Please select an image", Toast.LENGTH_SHORT).show()
            return
        }

        // Save the image to internal storage only if a new image is selected
        val imagePath = if (imageUri != null) saveImageToInternalStorage(imageUri!!) else null

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val storyDao = StoryDatabase.getInstance(applicationContext).storyDao()

                if (storyId == -1) {
                    // Insert new story
                    val newStory = Story(
                        title = title,
                        description = description,
                        author = author,
                        imagePath = imagePath ?: "", imageUri = imageUri
                    )
                    storyDao.insertStory(newStory)
                } else {
                    // Update existing story
                    val updatedStory = Story(
                        id = storyId, // Use the existing ID
                        title = title,
                        description = description,
                        author = author,
                        imagePath = imagePath ?: intent.getStringExtra("STORY_IMAGE_PATH") ?: "", imageUri = imageUri
                    )
                    storyDao.updateStory(updatedStory)
                }
            }

            // Notify user and close activity
            val message = if (storyId == -1) "Story saved successfully" else "Story updated successfully"
            withContext(Dispatchers.Main) {
                Toast.makeText(this@StoryUploadActivity, message, Toast.LENGTH_SHORT).show()
                finish() // Close activity
            }
        }
    }

    private fun saveImageToInternalStorage(uri: Uri): String? {
        return try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            // Create a file in internal storage
            val file = File(filesDir, "${System.currentTimeMillis()}.jpg")
            val outputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
            outputStream.flush()
            outputStream.close()

            file.absolutePath
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }
}

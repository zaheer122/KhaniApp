package com.example.khaniapp

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [SavedStory::class], version = 2)
abstract class SavedStoriesDatabase : RoomDatabase() {
    abstract fun savedStoryDao(): SavedStoryDao

    companion object {
        @Volatile
        private var INSTANCE: SavedStoriesDatabase? = null

        fun getInstance(context: Context): SavedStoriesDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SavedStoriesDatabase::class.java,
                    "saved_stories_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Add the 'author' column to the 'Story' table
                database.execSQL("ALTER TABLE saved_stories ADD COLUMN author TEXT NOT NULL DEFAULT 'Unknown'")
            }
        }
    }
}

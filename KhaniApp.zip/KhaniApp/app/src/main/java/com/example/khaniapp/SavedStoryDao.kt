package com.example.khaniapp

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface SavedStoryDao {
    @Insert
    suspend fun insertSavedStory(savedStory: SavedStory)

    @Query("SELECT * FROM saved_stories")
    fun getAllSavedStories(): LiveData<List<SavedStory>>

    @Delete
    fun delete(savedStory: SavedStory)
}

package com.example.khaniapp

import android.graphics.Canvas
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SavedStoriesFragment : Fragment() {
    private lateinit var savedStoriesAdapter: SavedStoriesAdapter
    private lateinit var savedStoriesRecyclerView: RecyclerView
    private lateinit var savedStoriesDatabase: SavedStoriesDatabase

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_saved_stories, container, false)
        savedStoriesRecyclerView = view.findViewById(R.id.recyclerViewSavedStories)
        savedStoriesAdapter = SavedStoriesAdapter()
        savedStoriesRecyclerView.adapter = savedStoriesAdapter
        savedStoriesRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        savedStoriesDatabase = SavedStoriesDatabase.getInstance(requireContext())

        loadSavedStories()

        val itemTouchHelper = ItemTouchHelper(createSwipeToDeleteCallback())
        itemTouchHelper.attachToRecyclerView(savedStoriesRecyclerView)

        return view
    }


    private fun loadSavedStories() {
        val savedStoryDao = SavedStoriesDatabase.getInstance(requireContext()).savedStoryDao()
        savedStoryDao.getAllSavedStories().observe(viewLifecycleOwner) { savedStories ->
            if (savedStories != null) {
                savedStoriesAdapter.submitList(savedStories)
            } else {
                Toast.makeText(requireContext(), "No saved stories found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createSwipeToDeleteCallback(): ItemTouchHelper.SimpleCallback {
        return object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false // No move action
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val savedStory = savedStoriesAdapter.currentList[position]

                // Remove from database and update the RecyclerView
                val savedStoryDao = savedStoriesDatabase.savedStoryDao()
                lifecycleScope.launch(Dispatchers.IO) {
                    savedStoryDao.delete(savedStory)
                }


                // Provide feedback with a Snackbar if needed
                Snackbar.make(savedStoriesRecyclerView, "Story removed", Snackbar.LENGTH_SHORT).show()
            }

            override fun onChildDraw(
                c: Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)

                // Customize background and icon here if needed
            }
        }
    }

}

package com.example.khaniapp

import android.content.Intent
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class StoryActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var imageViewStoryImage: ImageView
    private lateinit var textViewStoryTitle: TextView
    private lateinit var textViewStoryDescription: TextView
    private lateinit var textViewStoryAuthor: TextView
    private lateinit var buttonSaveStory: Button
    private lateinit var buttonShareStory: Button
    private lateinit var buttonListenStory: Button
    private var story: Story? = null
    private var textToSpeech: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_story)

        imageViewStoryImage = findViewById(R.id.imageViewStoryImage)
        textViewStoryTitle = findViewById(R.id.textViewStoryTitle)
        textViewStoryAuthor = findViewById(R.id.textViewStoryAuthor)
        textViewStoryDescription = findViewById(R.id.textViewStoryDescription)
        buttonSaveStory = findViewById(R.id.buttonSaveStory)
        buttonShareStory = findViewById(R.id.buttonShareStory)
        buttonListenStory = findViewById(R.id.buttonListenStory)


        textToSpeech = TextToSpeech(this, this)


        val storyId = intent.getIntExtra("STORY_ID", -1)
        if (storyId != -1) {
            loadStory(storyId)
        } else {
            Toast.makeText(this, "Story not found", Toast.LENGTH_SHORT).show()
            finish()
        }



        buttonSaveStory.setOnClickListener { saveStory() }
        buttonShareStory.setOnClickListener { shareStory() }
        buttonListenStory.setOnClickListener { listenStory() }

    }

    private fun loadStory(storyId: Int) {
        lifecycleScope.launch {
            story = withContext(Dispatchers.IO) {
                StoryDatabase.getInstance(applicationContext).storyDao().getStoryById(storyId)
            }
            story?.let { displayStory(it) }
        }
    }

    private fun displayStory(story: Story) {
        textViewStoryTitle.text = story.title
        textViewStoryDescription.text = story.description
        textViewStoryAuthor.text = story.author

        // Load image from the stored path
        val imgFile = File(story.imagePath)
        if (imgFile.exists()) {
            val bitmap = BitmapFactory.decodeFile(imgFile.absolutePath)
            imageViewStoryImage.setImageBitmap(bitmap)
        }
    }

    private fun saveStory() {
        // Here, you can implement any functionality for saving the story.
        // For instance, you could save it to another database or share it with another app.
        story?.let {
            val savedStory = SavedStory(
                title = it.title,
                description = it.description,
                author = it.author,
                imagePath = it.imagePath
            )

            lifecycleScope.launch(Dispatchers.IO) {
                SavedStoriesDatabase.getInstance(applicationContext).savedStoryDao().insertSavedStory(savedStory)
            }
            Toast.makeText(this, "Story saved to Saved Stories!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareStory() {
        story?.let {
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, it.title)
                putExtra(Intent.EXTRA_TEXT, "Story: ${it.title}\n\n${it.description}\n\n${it.author}")
            }
            startActivity(Intent.createChooser(shareIntent, "Share story via"))
        }
    }

    private fun listenStory() {
        story?.let {
            val textToRead = "${it.title}. ${it.description}. ${it.author}"
            textToSpeech?.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.language = Locale.getDefault()
        } else {
            Toast.makeText(this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }

}
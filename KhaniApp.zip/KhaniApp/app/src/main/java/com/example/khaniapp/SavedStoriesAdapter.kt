package com.example.khaniapp

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class SavedStoriesAdapter : ListAdapter<SavedStory, SavedStoriesAdapter.SavedStoryViewHolder>(SavedStoryDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SavedStoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_story_card, parent, false)
        return SavedStoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: SavedStoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class SavedStoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.textViewStoryTitle)
        private val descriptionTextView: TextView = itemView.findViewById(R.id.textViewStoryDescription)
        private val storyImageView: ImageView = itemView.findViewById(R.id.imageViewStoryImage)

        fun bind(savedStory: SavedStory) {
            titleTextView.text = savedStory.title
            descriptionTextView.text = savedStory.description
            val imgFile = File(savedStory.imagePath)
            if (imgFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(imgFile.absolutePath)
                storyImageView.setImageBitmap(bitmap)
            }
        }
    }
}

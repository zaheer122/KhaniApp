package com.example.khaniapp

data class Category(
    val name: String,
    val iconResId: Int
)
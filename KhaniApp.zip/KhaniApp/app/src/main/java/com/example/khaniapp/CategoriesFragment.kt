package com.example.khaniapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CategoriesFragment : Fragment() {

    private lateinit var categoriesRecyclerView: RecyclerView
    private lateinit var categoriesAdapter: CategoriesAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_categories, container, false)
        categoriesRecyclerView = view.findViewById(R.id.recyclerViewCategories)

        // Set up the adapter with sample categories
        categoriesAdapter = CategoriesAdapter(getCategories()) { category ->
            // Handle category click (e.g., navigate to category-specific story list)
            Toast.makeText(requireContext(), "Clicked on ${category.name}", Toast.LENGTH_SHORT).show()
        }

        categoriesRecyclerView.adapter = categoriesAdapter
        categoriesRecyclerView.layoutManager = GridLayoutManager(requireContext(), 2)

        return view
    }

    private fun getCategories(): List<Category> {
        return listOf(
            Category("Adventure", R.drawable.adventure),
            Category("Fantasy", R.drawable.fantasy),
            Category("Horror", R.drawable.horror),
            Category("Mystery", R.drawable.mystic),
            Category("Romance", R.drawable.romance),
            Category("Sci-Fi", R.drawable.scific)
        )
    }
}